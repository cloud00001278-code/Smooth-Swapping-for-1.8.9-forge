package dev.shwg.smoothswapping.handler;

import dev.shwg.smoothswapping.SmoothSwapping;
import dev.shwg.smoothswapping.SwapUtil;
import dev.shwg.smoothswapping.config.ConfigManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.GuiContainerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.List;

/**
 * Intercepts slot clicks in GuiContainer to handle QUICK_MOVE (shift-click)
 * and SWAP (number key) animations.
 *
 * In 1.8.9 Forge we don't have packet-level Mixins, so we hook the
 * GuiContainerEvent.SlotClick event fired by Forge after a slot action.
 */
@SideOnly(Side.CLIENT)
public class SlotClickHandler {

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public void onSlotClick(GuiContainerEvent.SlotClick event) {
        if (!ConfigManager.getConfig().getToggleMod()) return;

        GuiContainer gui = event.gui;
        Container container = gui.inventorySlots;
        List<Slot> slots = container.inventorySlots;

        int slotId = event.slot != null ? event.slot.slotNumber : -1;
        int mouseButton = event.mouseButton;
        int mode = event.mode;  // 0=normal, 1=shift, 5=hotbar swap

        // Remove any existing swap for the clicked slot (same as original)
        if (slotId >= 0) SmoothSwapping.swaps.remove(slotId);

        // mode 1 = QUICK_MOVE (shift-click), mode 5 = SWAP (number key swap)
        if ((mode == 1 || mode == 5) && slotId >= 0 && slots.size() > 1) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null) return;

            Slot mouseSlot = event.slot;
            if (mouseSlot == null) return;

            if (mode == 1) {
                // Shift-click: flag this slot so the render handler can track
                // that items are flowing *out* of it
                ItemStack newStack = mouseSlot.getStack();
                ItemStack oldStack = SmoothSwapping.oldStacks.size() > slotId ?
                        SmoothSwapping.oldStacks.get(slotId) : null;

                int newCount = newStack != null ? newStack.stackSize : 0;
                int oldCount = oldStack != null ? oldStack.stackSize : 0;

                if (newCount - oldCount <= 0) {
                    SmoothSwapping.clickSwapStack = slotId;
                }

            } else {
                // Number-key swap between slot and hotbar
                SmoothSwapping.clickSwap = true;

                // Find the hotbar slot being swapped with (mouseButton = hotbar index 0-8)
                int hotbarSlotId = mouseButton; // Forge passes hotbar index as mouseButton in mode 5
                if (hotbarSlotId >= 0 && hotbarSlotId < slots.size()) {
                    Slot hotbarSlot = slots.get(hotbarSlotId);
                    SmoothSwapping.swaps.remove(slotId);
                    SmoothSwapping.swaps.remove(hotbarSlotId);

                    if (hotbarSlot.getStack() != null && mouseSlot.getStack() != null) {
                        SwapUtil.addI2IInventorySwap(hotbarSlotId, mouseSlot, hotbarSlot, false, hotbarSlot.getStack().stackSize);
                        SwapUtil.addI2IInventorySwap(slotId, hotbarSlot, mouseSlot, false, mouseSlot.getStack().stackSize);
                    } else if (hotbarSlot.getStack() == null && mouseSlot.getStack() != null) {
                        SwapUtil.addI2IInventorySwap(hotbarSlotId, mouseSlot, hotbarSlot, false, mouseSlot.getStack().stackSize);
                    } else if (hotbarSlot.getStack() != null) {
                        SwapUtil.addI2IInventorySwap(slotId, hotbarSlot, mouseSlot, false, hotbarSlot.getStack().stackSize);
                    }
                }
            }
        }
    }
}
