package dev.shwg.smoothswapping;

import dev.shwg.smoothswapping.config.ConfigManager;
import dev.shwg.smoothswapping.handler.GuiContainerEventHandler;
import dev.shwg.smoothswapping.handler.SlotClickHandler;
import dev.shwg.smoothswapping.swaps.InventorySwap;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Mod(modid = SmoothSwapping.MOD_ID, name = "Smooth Swapping", version = "1.0.0",
     clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class SmoothSwapping {

    public static final String MOD_ID = "smoothswapping";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);
    public static final int ASSUME_CURSOR_STACK_SLOT_INDEX = -2;

    public static boolean clickSwap;
    public static Integer clickSwapStack;
    public static Map<Integer, List<InventorySwap>> swaps = new HashMap<>();
    public static List<ItemStack> oldStacks = new ArrayList<>();
    public static List<ItemStack> currentStacks = new ArrayList<>();
    public static ItemStack oldCursorStack;
    public static ItemStack currentCursorStack;

    @Mod.Instance(MOD_ID)
    public static SmoothSwapping instance;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ConfigManager.init();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new GuiContainerEventHandler());
        MinecraftForge.EVENT_BUS.register(new SlotClickHandler());
        LOGGER.info("Smooth Swapping initialized for 1.8.9 Forge.");
    }
}
