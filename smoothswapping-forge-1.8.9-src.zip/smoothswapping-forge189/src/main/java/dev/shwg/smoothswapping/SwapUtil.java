package dev.shwg.smoothswapping;

import dev.shwg.smoothswapping.swaps.InventorySwap;
import dev.shwg.smoothswapping.swaps.ItemToCursorInventorySwap;
import dev.shwg.smoothswapping.swaps.ItemToItemInventorySwap;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import static dev.shwg.smoothswapping.SmoothSwapping.ASSUME_CURSOR_STACK_SLOT_INDEX;
import static dev.shwg.smoothswapping.SmoothSwapping.currentStacks;
import static java.lang.Math.PI;

public class SwapUtil {

    public static boolean hasArrived(InventorySwap swap) {
        int quadrant = getQuadrant(swap.getAngle());
        double x = swap.getX();
        double y = swap.getY();
        if (quadrant == 0 && x > 0 && y > 0) return true;
        else if (quadrant == 1 && x < 0 && y > 0) return true;
        else if (quadrant == 2 && x < 0 && y < 0) return true;
        else return quadrant == 3 && x > 0 && y < 0;
    }

    public static int getSlotIndex(ItemStack stack) {
        for (int i = 0; i < currentStacks.size(); i++) {
            ItemStack s = currentStacks.get(i);
            if (s != null && s.hashCode() == stack.hashCode()) return i;
        }
        return -1;
    }

    public static void setRenderToTrue(List<InventorySwap> swapList) {
        for (InventorySwap swap : swapList) swap.setRenderDestinationSlot(true);
    }

    private static int getQuadrant(double angle) {
        return (int) (Math.floor(2 * angle / PI) % 4 + 4) % 4;
    }

    public static double map(double in, double inMin, double inMax, double outMax, double outMin) {
        return (in - inMin) / (inMax - inMin) * (outMax - outMin) + outMin;
    }

    public static void addI2IInventorySwap(int index, Slot fromSlot, Slot toSlot, boolean checked, int amount) {
        List<InventorySwap> swaps = SmoothSwapping.swaps.getOrDefault(index, new ArrayList<>());

        ItemStack toStack = toSlot.getStack();
        if (toStack == null) return;

        ItemStack swapStack = toStack.copy();
        swaps.add(new ItemToItemInventorySwap(fromSlot, toSlot, checked, amount, swapStack));
        SmoothSwapping.swaps.put(index, swaps);
    }

    public static void assignI2CSwaps(List<SwapStacks> lessStacks, Vec2 mousePos, net.minecraft.inventory.Container container) {
        ItemStack cursorStack = SmoothSwapping.currentCursorStack;
        if (cursorStack == null) return;

        for (SwapStacks lessStack : lessStacks) {
            Slot lessSlot = (Slot) container.inventorySlots.get(lessStack.getSlotID());
            List<InventorySwap> swaps = SmoothSwapping.swaps.getOrDefault(ASSUME_CURSOR_STACK_SLOT_INDEX, new ArrayList<>());

            ItemStack swapStack = lessStack.getOldStack();
            if (swapStack == null) return;

            swaps.add(new ItemToCursorInventorySwap(lessSlot, mousePos, lessStack.getOldStack(), false, lessStack.itemCountToChange));
            SmoothSwapping.swaps.put(ASSUME_CURSOR_STACK_SLOT_INDEX, swaps);
        }
    }

    public static void assignI2ISwaps(List<SwapStacks> moreStacks, List<SwapStacks> lessStacks, net.minecraft.inventory.Container container) {
        for (int i = 0; i < moreStacks.size(); i++) {
            SwapStacks moreStack = moreStacks.get(i);
            if (moreStack.itemCountToChange == 0) {
                moreStacks.remove(i--);
                continue;
            }
            Slot moreSlot = (Slot) container.inventorySlots.get(moreStack.getSlotID());

            int c = 0;
            while (moreStack.itemCountToChange < 0 && c < 64) {
                c++;
                for (int j = 0; j < lessStacks.size(); j++) {
                    SwapStacks lessStack = lessStacks.get(j);
                    int amount = 0;
                    while (lessStack.itemCountToChange != 0 && moreStack.itemCountToChange != 0) {
                        lessStack.itemCountToChange--;
                        moreStack.itemCountToChange++;
                        amount++;
                    }
                    Slot lessSlot = (Slot) container.inventorySlots.get(lessStack.getSlotID());
                    boolean sameItem = moreStack.getOldStack() != null && moreStack.getNewStack() != null &&
                            ItemStack.areItemsEqual(moreStack.getOldStack(), moreStack.getNewStack());
                    addI2IInventorySwap(moreStack.getSlotID(), lessSlot, moreSlot, sameItem, amount);
                    if (lessStack.itemCountToChange == 0) lessStacks.remove(j--);
                    if (moreStack.itemCountToChange == 0) break;
                }
            }
        }
    }

    public static int getCount(ItemStack stack) {
        return (stack == null) ? 0 : stack.stackSize;
    }

    public static void copyStacks(List<ItemStack> src, List<ItemStack> dst) {
        dst.clear();
        for (ItemStack stack : src) {
            dst.add(stack == null ? null : stack.copy());
        }
    }

    public static int swapListIndexOf(List<InventorySwap> list, Function<InventorySwap, Boolean> predicate) {
        for (int i = 0; i < list.size(); i++) {
            if (predicate.apply(list.get(i))) return i;
        }
        return -1;
    }

    public static void reset() {
        SmoothSwapping.clickSwap = false;
        SmoothSwapping.clickSwapStack = null;
        SmoothSwapping.swaps.clear();
        SmoothSwapping.oldStacks.clear();
        SmoothSwapping.currentStacks.clear();
        SmoothSwapping.oldCursorStack = null;
        SmoothSwapping.currentCursorStack = null;
    }
}
