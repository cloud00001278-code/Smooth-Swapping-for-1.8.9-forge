package dev.shwg.smoothswapping.swaps;

import dev.shwg.smoothswapping.Vec2;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ItemToItemInventorySwap extends InventorySwap {
    public ItemToItemInventorySwap(Slot fromSlot, Slot toSlot, boolean checked, int amount, ItemStack swapStack) {
        super(new Vec2(fromSlot.xDisplayPosition, fromSlot.yDisplayPosition),
              new Vec2(toSlot.xDisplayPosition, toSlot.yDisplayPosition),
              swapStack, checked, amount);
    }
}
