package dev.shwg.smoothswapping.config;

public class Config {
    private boolean toggleMod = true;
    private int animationSpeed = 100;

    public boolean getToggleMod() { return toggleMod; }
    public void setToggleMod(boolean value) { toggleMod = value; }

    public int getAnimationSpeed() { return animationSpeed; }
    public void setAnimationSpeed(int animationSpeed) { this.animationSpeed = animationSpeed; }

    public float getAnimationSpeedFormatted() { return animationSpeed / 100F; }

    // Linear easing (no Catmull-Rom curve in this port - not available in 1.8.9 easily)
    public double getEase(double progress) {
        return progress;
    }
}
