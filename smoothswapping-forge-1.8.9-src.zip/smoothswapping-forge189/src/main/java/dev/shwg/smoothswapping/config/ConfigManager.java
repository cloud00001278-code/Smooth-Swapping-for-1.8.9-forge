package dev.shwg.smoothswapping.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.Minecraft;

import java.io.*;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config config;
    private static File configFile;

    public static void init() {
        File configDir = new File(Minecraft.getMinecraft().mcDataDir, "config");
        if (!configDir.exists()) configDir.mkdirs();
        configFile = new File(configDir, "smoothswapping.json");
        config = new Config();
        load();
    }

    private static void load() {
        if (configFile == null) return;
        if (!configFile.exists()) {
            save();
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(configFile))) {
            Config parsed = GSON.fromJson(reader, Config.class);
            if (parsed != null) config = parsed;
        } catch (IOException e) {
            System.err.println("[SmoothSwapping] Could not load config, using defaults.");
        }
    }

    public static void save() {
        if (configFile == null) return;
        try (FileWriter writer = new FileWriter(configFile)) {
            writer.write(GSON.toJson(config));
        } catch (IOException e) {
            System.err.println("[SmoothSwapping] Could not save config.");
        }
    }

    public static Config getConfig() {
        if (config == null) config = new Config();
        return config;
    }
}
