package dev.shwg.smoothswapping.handler;

import dev.shwg.smoothswapping.SmoothSwapping;
import dev.shwg.smoothswapping.SwapStacks;
import dev.shwg.smoothswapping.SwapUtil;
import dev.shwg.smoothswapping.Vec2;
import dev.shwg.smoothswapping.config.Config;
import dev.shwg.smoothswapping.config.ConfigManager;
import dev.shwg.smoothswapping.swaps.InventorySwap;
import dev.shwg.smoothswapping.swaps.ItemToCursorInventorySwap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.GuiContainerEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SideOnly(Side.CLIENT)
public class GuiContainerEventHandler {

    private GuiContainer currentGui = null;

    // -------------------------------------------------------------------------
    // Per-frame update: detect changed stacks, assign swaps
    // Replaces HandledScreenMixin#onRender
    // -------------------------------------------------------------------------
    @SubscribeEvent
    public void onGuiDraw(GuiContainerEvent.DrawBackground event) {
        if (!ConfigManager.getConfig().getToggleMod()) return;

        GuiContainer gui = event.gui;
        Container container = gui.inventorySlots;

        try {
            doRender(gui, container);
        } catch (Exception e) {
            SwapUtil.reset();
        }
    }

    @SuppressWarnings("unchecked")
    private void doRender(GuiContainer gui, Container container) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        // Rebuild currentStacks from container slots
        SmoothSwapping.currentStacks.clear();
        List<Slot> slots = container.inventorySlots;
        for (Slot slot : slots) {
            SmoothSwapping.currentStacks.add(slot.getStack());
        }

        // Update cursor stack tracking
        ItemStack cursorStack = mc.thePlayer.inventory.getItemStack();
        SmoothSwapping.currentCursorStack = cursorStack != null ? cursorStack.copy() : null;

        // Screen change detection
        if (currentGui != gui) {
            SmoothSwapping.swaps.clear();
            SwapUtil.copyStacks(SmoothSwapping.currentStacks, SmoothSwapping.oldStacks);
            currentGui = gui;
            return;
        }

        if (SmoothSwapping.clickSwap) {
            SmoothSwapping.clickSwap = false;
            SwapUtil.copyStacks(SmoothSwapping.currentStacks, SmoothSwapping.oldStacks);
            return;
        }

        // Check for changed slots
        Map<Integer, ItemStack> changedStacks = getChangedStacks(SmoothSwapping.oldStacks, SmoothSwapping.currentStacks);

        int changedCount = changedStacks.size();
        if (changedCount > 1) {
            List<SwapStacks> moreStacks = new ArrayList<>();
            List<SwapStacks> lessStacks = new ArrayList<>();
            int totalAmount = 0;

            for (Map.Entry<Integer, ItemStack> entry : changedStacks.entrySet()) {
                int slotID = entry.getKey();
                ItemStack newStack = entry.getValue();
                ItemStack oldStack = getOrNull(SmoothSwapping.oldStacks, slotID);

                int newCount = SwapUtil.getCount(newStack);
                int oldCount = SwapUtil.getCount(oldStack);

                if (newCount > oldCount) {
                    moreStacks.add(new SwapStacks(slotID, oldStack, newStack, oldCount - newCount));
                    totalAmount += newCount - oldCount;
                } else if (newCount < oldCount && SmoothSwapping.clickSwapStack == null) {
                    lessStacks.add(new SwapStacks(slotID, oldStack, newStack, oldCount - newCount));
                }
            }

            if (SmoothSwapping.clickSwapStack != null) {
                lessStacks.clear();
                int csIdx = SmoothSwapping.clickSwapStack;
                ItemStack newStack = slots.get(csIdx).getStack();
                ItemStack oldStack = getOrNull(SmoothSwapping.oldStacks, csIdx);
                lessStacks.add(new SwapStacks(csIdx, oldStack, newStack, totalAmount));
                SmoothSwapping.clickSwapStack = null;
            }

            int guiLeft = getGuiLeft(gui);
            int guiTop = getGuiTop(gui);
            // We don't have mouse position here accurately, use center as fallback
            Vec2 mousePos = new Vec2(gui.width / 2.0 - guiLeft, gui.height / 2.0 - guiTop);

            if (moreStacks.isEmpty()) {
                SwapUtil.assignI2CSwaps(lessStacks, mousePos, container);
            } else {
                SwapUtil.assignI2ISwaps(moreStacks, lessStacks, container);
            }

        } else if (changedCount == 1) {
            ItemStack currentCursor = SmoothSwapping.currentCursorStack;
            ItemStack oldCursor = SmoothSwapping.oldCursorStack;

            if (currentCursor != null && oldCursor != null
                    && currentCursor.getItem() == oldCursor.getItem()
                    && currentCursor.stackSize != oldCursor.stackSize) {

                for (Map.Entry<Integer, ItemStack> entry : changedStacks.entrySet()) {
                    int slotID = entry.getKey();
                    ItemStack oldSlotStack = getOrNull(SmoothSwapping.oldStacks, slotID);
                    ItemStack currentSlotStack = SmoothSwapping.currentStacks.size() > slotID ?
                            SmoothSwapping.currentStacks.get(slotID) : null;
                    int cursorDiff = currentCursor.stackSize - oldCursor.stackSize;

                    if (oldSlotStack != null && currentSlotStack != null &&
                            ((ItemStack.areItemsEqual(oldSlotStack, currentSlotStack) &&
                              oldSlotStack.stackSize - currentSlotStack.stackSize == cursorDiff)
                             || currentSlotStack == null)) {

                        int guiLeft = getGuiLeft(gui);
                        int guiTop = getGuiTop(gui);
                        Vec2 mousePos = new Vec2(gui.width / 2.0 - guiLeft, gui.height / 2.0 - guiTop);
                        SwapStacks lessStack = new SwapStacks(slotID, oldSlotStack, currentSlotStack,
                                SwapUtil.getCount(oldSlotStack) - SwapUtil.getCount(currentSlotStack));
                        List<SwapStacks> ls = new ArrayList<>();
                        ls.add(lessStack);
                        SwapUtil.assignI2CSwaps(ls, mousePos, container);
                    }
                }
            }
        }

        if (!areStacksEqual(SmoothSwapping.oldStacks, SmoothSwapping.currentStacks)) {
            SwapUtil.copyStacks(SmoothSwapping.currentStacks, SmoothSwapping.oldStacks);
            SmoothSwapping.oldCursorStack = SmoothSwapping.currentCursorStack;
        }
    }

    // -------------------------------------------------------------------------
    // Render animated items on top of slots
    // Replaces DrawContextMixin
    // -------------------------------------------------------------------------
    @SubscribeEvent
    public void onGuiForeground(GuiContainerEvent.DrawForeground event) {
        if (!ConfigManager.getConfig().getToggleMod()) return;
        if (SmoothSwapping.swaps.isEmpty()) return;

        GuiContainer gui = event.gui;
        Container container = gui.inventorySlots;

        try {
            renderSwapAnimations(gui, container);
        } catch (Exception e) {
            SwapUtil.reset();
        }
    }

    @SuppressWarnings("unchecked")
    private void renderSwapAnimations(GuiContainer gui, Container container) {
        Minecraft mc = Minecraft.getMinecraft();
        Config config = ConfigManager.getConfig();
        float partialTicks = mc.timer.renderPartialTicks;
        float frameDelta = mc.timer.elapsedPartialTicks;

        List<Slot> slots = container.inventorySlots;

        // Render item-to-item swaps
        List<Integer> toRemove = new ArrayList<>();
        for (Map.Entry<Integer, List<InventorySwap>> entry : new HashMap<>(SmoothSwapping.swaps).entrySet()) {
            int slotIndex = entry.getKey();
            List<InventorySwap> swapList = entry.getValue();

            if (slotIndex == SmoothSwapping.ASSUME_CURSOR_STACK_SLOT_INDEX) continue;
            if (slotIndex < 0 || slotIndex >= slots.size()) continue;

            Slot destSlot = slots.get(slotIndex);
            int destX = destSlot.xDisplayPosition;
            int destY = destSlot.yDisplayPosition;

            List<InventorySwap> arrived = new ArrayList<>();

            for (InventorySwap swap : swapList) {
                swap.setRenderDestinationSlot(swap.isChecked());
                renderAnimatedItem(swap, destX, destY, config, frameDelta);
                if (SwapUtil.hasArrived(swap)) {
                    SwapUtil.setRenderToTrue(swapList);
                    arrived.add(swap);
                }
            }
            swapList.removeAll(arrived);
            if (swapList.isEmpty()) toRemove.add(slotIndex);
        }
        toRemove.forEach(SmoothSwapping.swaps::remove);

        // Render item-to-cursor swaps
        if (SmoothSwapping.swaps.containsKey(SmoothSwapping.ASSUME_CURSOR_STACK_SLOT_INDEX)) {
            List<InventorySwap> swapList = SmoothSwapping.swaps.get(SmoothSwapping.ASSUME_CURSOR_STACK_SLOT_INDEX);
            List<InventorySwap> arrivedList = new ArrayList<>();

            for (InventorySwap inv : swapList) {
                ItemToCursorInventorySwap swap = (ItemToCursorInventorySwap) inv;
                if (swap.isArrived()) { arrivedList.add(swap); continue; }

                if (!swap.isStartedRender()) {
                    swap.setStartedRender(true);
                } else {
                    // Find the source slot and animate from it toward cursor position
                    // We render at a relative position derived from swap state
                    renderAnimatedItem(swap, 0, 0, config, frameDelta);
                    if (SwapUtil.hasArrived(swap)) swap.setArrived(true);
                }
            }
            swapList.removeAll(arrivedList);
            boolean allArrived = swapList.stream().allMatch(s -> ((ItemToCursorInventorySwap) s).isArrived());
            if (allArrived) SmoothSwapping.swaps.remove(SmoothSwapping.ASSUME_CURSOR_STACK_SLOT_INDEX);
        }
    }

    private void renderAnimatedItem(InventorySwap swap, int destX, int destY, Config config, float frameDelta) {
        double swapX = swap.getX();
        double swapY = swap.getY();
        double angle = swap.getAngle();

        double progress = 1D - SwapUtil.map(Math.hypot(swapX, swapY), 0, swap.getDistance(), 1D, 0D);
        double ease = config.getEase(progress);

        double renderX = -swap.getStartX() - Math.cos(angle) * swap.getDistance() * ease;
        double renderY = swap.getStartY() + Math.sin(angle) * swap.getDistance() * ease;

        GL11.glPushMatrix();
        GL11.glTranslated(renderX, -renderY, 350);

        RenderHelper.enableGUIStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(
                swap.getSwapItem(), destX, destY);
        RenderHelper.disableStandardItemLighting();

        GL11.glPopMatrix();

        // Advance position
        double speed = swap.getDistance() / 10.0 * config.getAnimationSpeedFormatted();
        swap.setX(swapX + frameDelta * speed * Math.cos(angle));
        swap.setY(swapY + frameDelta * speed * Math.sin(angle));
    }

    // -------------------------------------------------------------------------
    // Detect slot clicks to handle QUICK_MOVE / SWAP actions
    // Replaces ClickSlotPacketMixin
    // -------------------------------------------------------------------------
    @SubscribeEvent
    public void onGuiMouseClick(GuiScreenEvent.MouseInputEvent.Pre event) {
        if (!(event.gui instanceof GuiContainer)) return;
        if (!ConfigManager.getConfig().getToggleMod()) return;
        // Slot click interception is handled via GuiContainerClickHandler below
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private Map<Integer, ItemStack> getChangedStacks(List<ItemStack> oldStacks, List<ItemStack> newStacks) {
        Map<Integer, ItemStack> changed = new HashMap<>();
        int size = Math.min(oldStacks.size(), newStacks.size());
        for (int i = 0; i < size; i++) {
            ItemStack o = oldStacks.get(i);
            ItemStack n = newStacks.get(i);
            if (!areItemStacksEqual(o, n)) {
                changed.put(i, n != null ? n.copy() : null);
            }
        }
        return changed;
    }

    private boolean areStacksEqual(List<ItemStack> a, List<ItemStack> b) {
        if (a == null || b == null || a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) {
            if (!areItemStacksEqual(a.get(i), b.get(i))) return false;
        }
        return true;
    }

    private boolean areItemStacksEqual(ItemStack a, ItemStack b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return ItemStack.areItemStacksEqual(a, b);
    }

    private ItemStack getOrNull(List<ItemStack> list, int index) {
        if (index < 0 || index >= list.size()) return null;
        return list.get(index);
    }

    private int getGuiLeft(GuiContainer gui) {
        try {
            java.lang.reflect.Field f = GuiContainer.class.getDeclaredField("guiLeft");
            f.setAccessible(true);
            return f.getInt(gui);
        } catch (Exception e) { return 0; }
    }

    private int getGuiTop(GuiContainer gui) {
        try {
            java.lang.reflect.Field f = GuiContainer.class.getDeclaredField("guiTop");
            f.setAccessible(true);
            return f.getInt(gui);
        } catch (Exception e) { return 0; }
    }
}
