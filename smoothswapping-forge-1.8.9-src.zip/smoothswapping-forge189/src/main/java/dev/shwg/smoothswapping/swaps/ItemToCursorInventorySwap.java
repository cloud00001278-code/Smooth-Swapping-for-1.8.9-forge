package dev.shwg.smoothswapping.swaps;

import dev.shwg.smoothswapping.Vec2;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ItemToCursorInventorySwap extends InventorySwap {
    private boolean startedRender;
    private int copiedStackHash;
    private int targetStackHash;
    private boolean arrived;

    public ItemToCursorInventorySwap(Slot fromSlot, Vec2 relativeCursorPos, ItemStack fromStack, boolean checked, int amount) {
        // slot icon center = slot position + 8 (slots are 16x16)
        super(new Vec2(fromSlot.xDisplayPosition + 8, fromSlot.yDisplayPosition + 8),
              relativeCursorPos, fromStack, checked, amount);
        startedRender = false;
        arrived = false;
        targetStackHash = -1;
    }

    public boolean isStartedRender() { return startedRender; }
    public void setStartedRender(boolean startedRender) { this.startedRender = startedRender; }
    public int getCopiedStackHash() { return copiedStackHash; }
    public void setCopiedStackHash(int copiedStackHash) { this.copiedStackHash = copiedStackHash; }
    public int getTargetStackHash() { return targetStackHash; }
    public void setTargetStackHash(int targetStackHash) { this.targetStackHash = targetStackHash; }
    public boolean isArrived() { return arrived; }
    public void setArrived(boolean arrived) { this.arrived = arrived; }
}
