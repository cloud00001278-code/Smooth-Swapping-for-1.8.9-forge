package dev.shwg.smoothswapping;

public class Vec2 implements Comparable<Vec2> {
    static double Resolution = 72;
    static int xoffset = 120;
    static int yoffset = 120;
    public double[] v;

    public Vec2() { this(0, 0); }

    public Vec2(double x, double y) {
        v = new double[2];
        set(x, y);
    }

    public Vec2(Vec2 src) { this(src.v[0], src.v[1]); }

    public Vec2 set(double x, double y) {
        v[0] = x; v[1] = y;
        return this;
    }

    public Vec2 copy() { return new Vec2(this); }

    public double magn() { return Math.sqrt(v[0] * v[0] + v[1] * v[1]); }

    public Vec2 translate(double tx, double ty) {
        v[0] += tx; v[1] += ty;
        return this;
    }

    static public Vec2 diff(Vec2 a, Vec2 b) {
        return new Vec2(a.v[0] - b.v[0], a.v[1] - b.v[1]);
    }

    @Override
    public int compareTo(Vec2 o) {
        return Double.compare(this.v[0], o.v[0]);
    }

    @Override
    public String toString() {
        return String.format("[%.3g %.3g]", v[0], v[1]);
    }
}
